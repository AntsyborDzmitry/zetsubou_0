define(["exports", "module"], function (exports, module) {
  "use strict";

  module.exports = CustomClearanceController;

  function CustomClearanceController() {}
});
//# sourceMappingURL=optional-services-controller.js.map
