define(['exports', 'ewf', './ewf-account-field-controller'], function (exports, _ewf, _ewfAccountFieldController) {
    'use strict';

    var _slicedToArray = (function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i['return']) _i['return'](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError('Invalid attempt to destructure non-iterable instance'); } }; })();

    function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

    var _ewf2 = _interopRequireDefault(_ewf);

    var _AccountFieldController = _interopRequireDefault(_ewfAccountFieldController);

    _ewf2['default'].directive('ewfAccountField', ewfFieldAccount);

    function ewfFieldAccount() {
        return {
            restrict: 'A',
            require: ['ewfAccountField', '^registrationForm'],
            scope: true,
            controller: _AccountFieldController['default'],
            controllerAs: 'accountFieldController',
            link: link
        };

        function link(scope, element, attrs, controllers) {
            var _controllers = _slicedToArray(controllers, 1);

            var accountFieldController = _controllers[0];

            var fieldId = attrs.ewfAccountField;
            accountFieldController.setFieldId(fieldId);
        }
    }
});
//# sourceMappingURL=ewf-account-field-directive.js.map
