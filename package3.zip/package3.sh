#!/bin/sh
java -cp ./resources -jar ./resources/package3-update.jar
read -r -p "Press any key to continue..."